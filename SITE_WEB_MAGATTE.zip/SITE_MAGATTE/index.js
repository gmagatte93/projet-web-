// Fonction de validation du formulaire d'inscription
function validateForm() {
    let nom = document.getElementById("nom").value;
    let prenom = document.getElementById("prenom").value;
    let email = document.getElementById("email").value;
    let dateNaissance = document.getElementById("date_naissance").value;
    let numeroRegistre = document.getElementById("numero_registre").value;

    // Vérification des champs obligatoires
    if (nom == "" || prenom == "" || email == "") {
        alert("Veuillez remplir tous les champs obligatoires.");
        return false;
    }

    // Vérification de l'email
    let emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!email.match(emailRegex)) {
        alert("Veuillez entrer un email valide.");
        return false;
    }

    // Vérification de la date de naissance 
    if (dateNaissance && !isValidDate(dateNaissance)) {
        alert("La date de naissance n'est pas valide.");
        return false;
    }

    if (numeroRegistre && !numeroRegistre.match(/^\d+$/)) {
        alert("Le numéro de registre doit être un nombre.");
        return false;
    }

    // Si toutes les validations sont réussies
    return true;
}

// Fonction de validation pour la date (format : YYYY-MM-DD)
function isValidDate(date) {
    let regex = /^\d{4}-\d{2}-\d{2}$/;
    return regex.test(date);
}

// Fonction de validation du formulaire de rendez-vous
function validateRdvForm() {
    let nom = document.getElementById("nom").value;
    let email = document.getElementById("email").value;
    let telephone = document.getElementById("telephone").value;
    let dateNaissance = document.getElementById("date_naissance").value;
    let dateRdv = document.getElementById("date_rdv").value;
    let numeroRegistre = document.getElementById("numero_registre").value;

    // Vérification des champs obligatoires
    if (nom == "" || email == "" || telephone == "" || dateRdv == "" || numeroRegistre == "") {
        alert("Veuillez remplir tous les champs obligatoires.");
        return false;
    }

    // Vérification de l'email
    let emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!email.match(emailRegex)) {
        alert("Veuillez entrer un email valide.");
        return false;
    }

    // Vérification du téléphone (format simple)
    let phoneRegex = /^[0-9]{9,15}$/;
    if (!telephone.match(phoneRegex)) {
        alert("Veuillez entrer un numéro de téléphone valide.");
        return false;
    }

    // Vérification de la date de naissance 
    if (dateNaissance && !isValidDate(dateNaissance)) {
        alert("La date de naissance n'est pas valide.");
        return false;
    }

    // Vérification de la date du rendez-vous
    if (dateRdv && !isValidDate(dateRdv)) {
        alert("La date du rendez-vous n'est pas valide.");
        return false;
    }

    // Vérification du numéro de registre (il doit être numérique)
    if (numeroRegistre && !numeroRegistre.match(/^\d+$/)) {
        alert("Le numéro de registre doit être un nombre.");
        return false;
    }

    // Si toutes les validations sont réussies
    return true;
}

// Fonction de validation pour la date (format : YYYY-MM-DD)
function isValidDate(date) {
    let regex = /^\d{4}-\d{2}-\d{2}$/;
    return regex.test(date);
}

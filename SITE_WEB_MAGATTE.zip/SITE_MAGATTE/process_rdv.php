<?php
require 'connexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom_complet = htmlspecialchars($_POST['nom']);
    $date_naissance = $_POST['naissance'];
    $telephone = htmlspecialchars($_POST['tel']);
    $email = htmlspecialchars($_POST['email']);
    $date_rdv = $_POST['date'];
    $numero_registre = htmlspecialchars($_POST['registre']);
    $service = htmlspecialchars($_POST['service']);

    $sql = "INSERT INTO rendezvous (nom_complet, date_naissance, telephone, email, date_rdv, numero_registre, service)
            VALUES (:nom, :naissance, :tel, :email, :date, :registre, :service)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nom' => $nom_complet,
        ':naissance' => $date_naissance,
        ':tel' => $telephone,
        ':email' => $email,
        ':date' => $date_rdv,
        ':registre' => $numero_registre,
        ':service' => $service
    ]);
    echo " Rendez-vous enregistré avec succès.";
}
?>
<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['nom'], $_POST['date_naissance'], $_POST['telephone'], $_POST['email'], $_POST['date_rdv'], $_POST['service'])) {
        $nom = $_POST['nom'];
        $date_naissance = $_POST['date_naissance'];
        $telephone = $_POST['telephone'];
        $email = $_POST['email'];
        $date_rdv = $_POST['date_rdv'];
        $service = $_POST['service'];
        $numero_registre = $_POST['numero_registre'] ?? '';

        $stmt = $pdo->prepare("INSERT INTO rendezvous (nom_complet, date_naissance, telephone, email, date_rdv, service, numero_registre, date_enregistrement, statut)
                               VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), 'en attente')");

        $stmt->execute([$nom, $date_naissance, $telephone, $email, $date_rdv, $service, $numero_registre]);

        echo "Votre demande de rendez-vous a été envoyée avec succès.";
    } else {
        echo "Une ou plusieurs informations sont manquantes. Veuillez réessayer.";
    }
}
?>

<?php
session_start();
require_once 'config.php';

// Redirection si non connecté, mais sauvegarde de l’URL demandée
if (!isset($_SESSION['utilisateur'])) {
    $_SESSION['retour_apres_login'] = $_SERVER['REQUEST_URI'];
    header("Location: connexion.php");
    exit();
}

$email = $_SESSION['utilisateur'];
$service_selectionne = $_GET['service'] ?? '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        isset($_POST['nom'], $_POST['date_naissance'], $_POST['telephone'], $_POST['date_rdv'], $_POST['service'])
    ) {
        $nom = $_POST['nom'];
        $date_naissance = $_POST['date_naissance'];
        $telephone = $_POST['telephone'];
        $date_rdv = $_POST['date_rdv'];
        $service = $_POST['service'];
        $numero_registre = $_POST['numero_registre'] ?? '';

        $stmt = $pdo->prepare("INSERT INTO rendezvous (nom_complet, date_naissance, telephone, email, date_rdv, service, numero_registre, date_enregistrement, statut) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), 'en attente')");
        $stmt->execute([$nom, $date_naissance, $telephone, $email, $date_rdv, $service, $numero_registre]);

        echo "<p style='color:green;'>Votre demande de rendez-vous a été envoyée avec succès.</p>";
    } else {
        echo "<p style='color:red;'>Tous les champs requis n'ont pas été remplis.</p>";
    }
}

// Récupérer les rendez-vous
$stmt = $pdo->prepare("SELECT * FROM rendezvous WHERE email = ? ORDER BY date_enregistrement DESC");
$stmt->execute([$email]);
$rendezvous = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes rendez-vous</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .rdv {
            border: 1px solid #ccc;
            padding: 10px;
            margin: 10px 0;
            background-color: #f9f9f9;
        }
        .statut { font-weight: bold; }
        .en-attente { color: orange; }
        .accepté { color: green; }
        .refusé { color: red; }
        .logout {
            text-align: right;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="logout">
        Connecté en tant que : <strong><?= htmlspecialchars($email) ?></strong> |
        <a href="logout.php" style="color: red;">Se déconnecter</a>
    </div>

    <h2>Prendre un rendez-vous</h2>
    <form method="post">
        <label>Nom complet :</label><br>
        <input type="text" name="nom" required><br><br>

        <label>Date de naissance :</label><br>
        <input type="date" name="date_naissance" required><br><br>

        <label>Téléphone :</label><br>
        <input type="text" name="telephone" required><br><br>

        <label>Date de rendez-vous souhaitée :</label><br>
        <input type="date" name="date_rdv" required><br><br>

        <label>Service demandé :</label><br>
        <select name="service" required>
            <option value="extrait_naissance" <?= $service_selectionne === 'extrait_naissance' ? 'selected' : '' ?>>Extrait de naissance</option>
            <option value="bulletin_naissance" <?= $service_selectionne === 'bulletin_naissance' ? 'selected' : '' ?>>Bulletin de naissance</option>
            <option value="certificat_celibat" <?= $service_selectionne === 'certificat_celibat' ? 'selected' : '' ?>>Certificat de célibat</option>
            <option value="bulletin_deces" <?= $service_selectionne === 'bulletin_deces' ? 'selected' : '' ?>>Bulletin de décès</option>
            <option value="certificat_mariage" <?= $service_selectionne === 'certificat_mariage' ? 'selected' : '' ?>>Certificat de mariage</option>
            <option value="certificat_divorce" <?= $service_selectionne === 'certificat_divorce' ? 'selected' : '' ?>>Certificat de divorce</option>
            <option value="extrait_reconnaissance" <?= $service_selectionne === 'extrait_reconnaissance' ? 'selected' : '' ?>>Extrait de reconnaissance</option>
            <option value="certificat_residence" <?= $service_selectionne === 'certificat_residence' ? 'selected' : '' ?>>Certificat de résidence</option>
        </select><br><br>

        <label>Numéro de registre (si applicable) :</label><br>
        <input type="text" name="numero_registre"><br><br>

        <button type="submit">Envoyer la demande</button>
    </form>

    <hr>

    <h2>Mes rendez-vous</h2>
    <?php if (count($rendezvous) === 0): ?>
        <p>Aucun rendez-vous enregistré.</p>
    <?php else: ?>
        <?php foreach ($rendezvous as $rdv): ?>
            <div class="rdv">
                <strong>Date RDV :</strong> <?= htmlspecialchars($rdv['date_rdv']) ?><br>
                <strong>Service :</strong> <?= htmlspecialchars($rdv['service']) ?><br>
                <strong>Statut :</strong> 
                <span class="statut <?= $rdv['statut'] ?>">
                    <?= htmlspecialchars($rdv['statut']) ?>
                </span>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>

<?php
$host = 'localhost';
$db   = 'gueyeh25techinfo_magatte_site';
$user = 'gueyeh25techinfo_magatte';
$pass = 'B@yeniass';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

try {
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}
?>

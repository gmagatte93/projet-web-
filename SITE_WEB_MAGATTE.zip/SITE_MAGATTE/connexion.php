<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Démarre la session si elle n'est pas déjà active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];
    $motdepasse = $_POST["motdepasse"];

    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE courriel = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($motdepasse, $user['mot_de_passe'])) {
        $_SESSION["utilisateur"] = $user["courriel"];

        if ($user["courriel"] === "gueye@420.techinfo") {
            header("Location: admin.php");
        } else {
            // redirection vers la dernière page demandée si disponible
            $destination = $_SESSION['retour_apres_login'] ?? 'mes_rendezvous.php';
            unset($_SESSION['retour_apres_login']);
            header("Location: $destination");
        }
        exit;
    } else {
        $erreur = "Identifiants incorrects.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
</head>
<body>
    <h2>Connexion</h2>
    <?php if (isset($erreur)) echo "<p style='color:red;'>$erreur</p>"; ?>
    <form method="POST">
        <label>Email :</label><br>
        <input type="email" name="email" required><br><br>

        <label>Mot de passe :</label><br>
        <input type="password" name="motdepasse" required><br><br>

        <button type="submit">Se connecter</button>
    </form>
</body>
</html>

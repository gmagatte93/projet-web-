<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Vérifier si toutes les données sont bien envoyées
    if (isset($_POST['nom'], $_POST['date_naissance'], $_POST['telephone'], $_POST['email'], $_POST['date_rdv'], $_POST['service'])) {
        // Récupérer les valeurs du formulaire
        $nom = $_POST['nom'];
        $date_naissance = $_POST['date_naissance'];
        $telephone = $_POST['telephone'];
        $email = $_POST['email'];
        $date_rdv = $_POST['date_rdv'];
        $service = $_POST['service'];  // Récupérer le service sélectionné
        $numero_registre = isset($_POST['numero_registre']) ? $_POST['numero_registre'] : '';  // Si applicable
        
        // Vous pouvez ensuite enregistrer ces données dans un fichier ou une base de données
        // Par exemple, enregistrer dans un fichier texte
        $data = $nom.$date_naissance.$telephone.$email.$date_rdv.$service.$numero_registre."\n";
        file_put_contents('rendezvous.txt', $data, FILE_APPEND);
        
        // Afficher un message de confirmation ou rediriger vers une autre page
        echo "Votre demande de rendez-vous a été envoyée avec succès.";
    } else {
        echo "Une ou plusieurs informations sont manquantes. Veuillez réessayer.";
    }
}
?>

<?php
session_start();
require_once 'config.php';

// Liens de navigation
echo "<div style='margin-bottom: 20px;'>
    <a href='index.html'> Accueil</a> | 
    <a href='logout.php'> Se déconnecter</a>
</div>";

// Rediriger si l'utilisateur n'est pas connecté
if (!isset($_SESSION['utilisateur'])) {
    echo "Accès refusé. Vous devez être connecté.";
    exit();
}

$emailConnecte = $_SESSION['utilisateur'];

if ($emailConnecte === 'gueye@420.techinfo') {
    // ADMIN : gérer les actions
    if (isset($_GET['accepter'])) {
        $id = (int)$_GET['accepter'];
        $pdo->prepare("UPDATE rendezvous SET statut = 'accepté' WHERE id = ?")->execute([$id]);
    }

    if (isset($_GET['refuser'])) {
        $id = (int)$_GET['refuser'];
        $pdo->prepare("UPDATE rendezvous SET statut = 'refusé' WHERE id = ?")->execute([$id]);
    }

    // Affichage des rendez-vous
    echo "<h2>Liste des rendez-vous (admin)</h2>";

    $stmt = $pdo->query("SELECT * FROM rendezvous ORDER BY date_enregistrement DESC");

    while ($rdv = $stmt->fetch()) {
        echo "<div style='border:1px solid #ccc;padding:10px;margin:10px;background-color:#f9f9f9'>";
        echo "<strong>Nom :</strong> " . htmlspecialchars($rdv['nom_complet']) . "<br>";
        echo "<strong>Email :</strong> " . htmlspecialchars($rdv['email']) . "<br>";
        echo "<strong>Date RDV :</strong> " . htmlspecialchars($rdv['date_rdv']) . "<br>";
        echo "<strong>Service :</strong> " . htmlspecialchars($rdv['service']) . "<br>";
        echo "<strong>Statut :</strong> " . htmlspecialchars($rdv['statut']) . "<br>";

        // Boutons admin
        if ($rdv['statut'] !== 'accepté') {
            echo "<a href='admin.php?accepter={$rdv['id']}'> Accepter</a> ";
        }
        if ($rdv['statut'] !== 'refusé') {
            echo "| <a href='admin.php?refuser={$rdv['id']}'> Refuser</a>";
        }
        echo "</div>";
    }

} else {
    // UTILISATEUR NORMAL : ses propres rendez-vous
    $stmt = $pdo->prepare("SELECT * FROM rendezvous WHERE email = ? ORDER BY date_enregistrement DESC");
    $stmt->execute([$emailConnecte]);
    $rendezvous = $stmt->fetchAll();

    echo "<h2>Mes rendez-vous</h2>";

    foreach ($rendezvous as $rdv) {
        echo "<div style='border:1px solid #ccc;padding:10px;margin:10px;background-color:#eef'>";
        echo "<strong>Date RDV :</strong> " . htmlspecialchars($rdv['date_rdv']) . "<br>";
        echo "<strong>Service :</strong> " . htmlspecialchars($rdv['service']) . "<br>";
        echo "<strong>Statut :</strong> " . htmlspecialchars($rdv['statut']) . "<br>";
        echo "</div>";
    }
}
?>

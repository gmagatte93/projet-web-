<?php
// Traitement de l'inscription utilisateur
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Logique de validation (simuler la base de données pour l'exemple)
    if (empty($firstname) || empty($lastname) || empty($email) || empty($phone)) {
        echo "Tous les champs doivent être remplis.";
        exit;
    }

    // Simuler l'ajout des informations dans une "base de données"
    // (ici un tableau simple pour l'exemple)
    $userData = [
        'firstname' => $firstname,
        'lastname' => $lastname,
        'email' => $email,
        'phone' => $phone,
    ];

    // Affichage des informations saisies (simulation)
    echo "<h2>Inscription réussie !</h2>";
    echo "<p>Merci pour votre inscription, " . htmlspecialchars($firstname) . " " . htmlspecialchars($lastname) . ".</p>";
    echo "<p>Email : " . htmlspecialchars($email) . "<br> Téléphone : " . htmlspecialchars($phone) . "</p>";
}
?>

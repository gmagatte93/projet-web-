<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once 'config.php';
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'] ?? '';
    $courriel = $_POST['courriel'] ?? '';
    $mot_de_passe = password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT);
    if ($nom && $courriel && $_POST['mot_de_passe']) {
        $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, courriel, mot_de_passe) VALUES (?, ?, ?)");
        $stmt->execute([$nom, $courriel, $mot_de_passe]);
        $message = " Utilisateur enregistré avec succès.";
    } else {
        $message = " Tous les champs sont requis.";
    }
}
?>
<h2>Inscription</h2>
<form method="post">
  <input type="text" name="nom" placeholder="Nom complet" required><br><br>
  <input type="email" name="courriel" placeholder="Adresse courriel" required><br><br>
  <input type="password" name="mot_de_passe" placeholder="Mot de passe" required><br><br>
  <button type="submit">S'inscrire</button>
</form>
<p><?php echo $message; ?></p>

<?php
session_start();

// Utilisateur et mot de passe administrateur (nom d'utilisateur: admin, mot de passe: GUEYE)
$admin_utilisateur = "admin";  // Nom d'utilisateur
$admin_mot_de_passe = "GUEYE";  // Mot de passe

// Vérifier si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les informations du formulaire
    $utilisateur = $_POST['username'];
    $mot_de_passe = $_POST['password'];

    // Vérification des informations de connexion
    if ($utilisateur == $admin_utilisateur && $mot_de_passe == $admin_mot_de_passe) {
        // Si l'utilisateur est validé, on crée une session
        $_SESSION['utilisateur'] = $utilisateur;

        // Rediriger l'utilisateur vers la page des rendez-vous
        header("Location: rdv.php");
        exit();
    } else {
        // Si l'utilisateur ou le mot de passe est incorrect, afficher un message d'erreur
        echo "<p style='color: red;'>Nom d'utilisateur ou mot de passe incorrect.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Connexion - Mairie Dakar Plateau</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="info-bar">
        <p>📞 (+221) 33 849 81 81 | Du Lundi au Vendredi: 08h - 16h</p>
    </div>

    <header>
        <div class="navbar">
            <div class="logo">
                <img src="images/logo.png" alt="Mairie Dakar Plateau">
            </div>
        </div>
    </header>

    <main>
        <section class="form-section">
            <h1>Connexion Administrateur/Employé</h1>
            <form action="login.php" method="POST">
                <label for="username">Nom d'utilisateur:</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Mot de passe:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Se connecter</button>
            </form>
        </section>
    </main>

    <footer>
        <div class="footer-content">
            <div class="contact-info">
                <h3>Contact</h3>
                <p><strong>Adresse:</strong> Avenue Macky SALL, Dakar</p>
                <p><strong>Téléphone:</strong> (+221) 33 849 81 81</p>
                <p><strong>Email:</strong> contact@dakarplateau.com</p>
            </div>
        </div>
        <p>&copy; 2025 Mairie Dakar Plateau - Tous droits réservés.</p>
    </footer>

</body>
</html>

<?php

$file_path = "rendezvous.txt";

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page Admin - Mairie Dakar Plateau</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="info-bar">
        <p>📞 (+221) 33 849 81 81 | Du Lundi au Vendredi: 08h - 16h</p>
    </div>

    <header>
        <div class="navbar">
            <div class="logo">
                <img src="images/logo.png" alt="Mairie Dakar Plateau">
            </div>
        </div>
    </header>

    <main>
        

        <section class="file-download-section">
            <h2>Télécharger le fichier :</h2>
            <?php
            if (file_exists($file_path)) {
                echo '<a href="' . $file_path . '" download>Télécharger le fichier .txt</a>';
            } else {
                echo '<p>Le fichier n\'est pas disponible pour le téléchargement.</p>';
            }
            ?>
        </section>
        
    </main>

    <footer>
        <div class="footer-content">
            <div class="contact-info">
                <h3>Contact</h3>
                <p><strong>Adresse:</strong> Avenue Macky SALL, Dakar</p>
                <p><strong>Téléphone:</strong> (+221) 33 849 81 81</p>
                <p><strong>Email:</strong> contact@dakarplateau.com</p>
            </div>
        </div>
        <p>&copy; 2025 Mairie Dakar Plateau - Tous droits réservés.</p>
    </footer>

</body>
</html>
